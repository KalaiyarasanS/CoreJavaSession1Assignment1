package session1;

public class Assignment2 {

	public static void main(String[] args) {

		int a,b=4,c;
		
		System.out.println("Value of b = "+b);
	}

}
