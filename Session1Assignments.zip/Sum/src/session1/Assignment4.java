package session1;

public class Assignment4 {

	public static void main(String[] args) {
		
		int x=5;
		int y=10;
		
		System.out.println("X+Y*2 	= "+(x+y*2));
		System.out.println("X-Y+2 	= "+(x-y+2));
		System.out.println("(X+Y)*2 = "+((x+y)*2));
		System.out.println("Y%X 	= "+(y%x));
	}

}
