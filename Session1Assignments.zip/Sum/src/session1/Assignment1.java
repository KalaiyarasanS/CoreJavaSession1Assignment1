package session1;

public class Assignment1 {

	public static void main(String[] args) {
		
		int num1 = 10;
		float num2 = 15.5f;
		int result;
		
		result = num1 + (int)num2;
		System.out.println("Sum of two numbers = "+result);
	}

}
